word = input()
password = ''

for j in word:
    if (j == 'i'):
        password += '!'
    elif (j == 'a'):
        password += '@'
    elif (j == 'm'):
        password += 'M'
    elif (j == 'B'):
        password += '8'
    elif (j == 'o'):
        password += '.'
    else:
        password += j
print(password + str('q*s'))
    