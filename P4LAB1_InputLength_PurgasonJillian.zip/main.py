user_text = input()
total = 0

for i in range(len(user_text)):
    if ((user_text[i] >= 'a' and user_text[i] <= 'z') or (user_text[i] >= 'A' and user_text[i] <= 'Z')):
        total += 1
    elif ((user_text[i] == ' ') or (user_text[i] == '.') or (user_text[i] == ',')):
        total += 0
    else:
        total += 1
print(total)


